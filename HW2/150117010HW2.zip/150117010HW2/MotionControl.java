
public interface MotionControl {
	
	// this interface represents the property of motion capturing for a smart device
	boolean controlMotion(boolean hasMotion, boolean isDay);
}
