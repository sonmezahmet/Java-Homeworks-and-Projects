
public interface LocationControl {

	// this interface represents the property of controlling a smart device based on the location of a household
	void onLeave();
	void onCome();
}
